import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import HomeScreen from "./screens/HomeScreen";
import AddMenuScreen from "./screens/AddMenuScreen";
import FilterScreen from "./screens/FilterScreen";

const Stack = createNativeStackNavigator();

export default function App() {
  const [menu, setMenu] = useState([]);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home">
          {(props) => (
            <HomeScreen
              {...props}
              menu={menu}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Add Menu">
          {(props) => (
            <AddMenuScreen
              {...props}
              menu={menu}
              setMenu={setMenu}
            />
          )}
        </Stack.Screen>

        <Stack.Screen name="Filter">
          {(props) => (
            <FilterScreen
              {...props}
              menu={menu}
            />
          )}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}