import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  StyleSheet
} from "react-native";

export default function AddMenuScreen({
  menu,
  setMenu
}) {

  const [name, setName] =
    useState("");

  const [description,
    setDescription] =
    useState("");

  const [price, setPrice] =
    useState("");

  const [course,
    setCourse] =
    useState("Starter");

  const courses = [
    "Starter",
    "Main",
    "Dessert"
  ];

  const addItem = () => {

    if (
      !name ||
      !description ||
      !price
    ) {
      Alert.alert(
        "Error",
        "Fill all fields"
      );
      return;
    }

    const newItem = {
      id: Date.now().toString(),
      name,
      description,
      price: Number(price),
      course
    };

    setMenu([newItem, ...menu]);

    setName("");
    setDescription("");
    setPrice("");
  };

  const deleteItem = (id) => {
    setMenu(
      menu.filter(
        item => item.id !== id
      )
    );
  };

  return (
    <View style={styles.container}>

      <TextInput
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
        style={styles.input}
      />

      <TextInput
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />

      <TextInput
        placeholder="Price"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
        style={styles.input}
      />

      <View style={styles.row}>
        {courses.map((c) => (
          <TouchableOpacity
            key={c}
            style={[
              styles.courseBtn,
              course === c &&
              styles.selected
            ]}
            onPress={() =>
              setCourse(c)
            }
          >
            <Text>{c}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={styles.button}
        onPress={addItem}
      >
        <Text style={styles.btnText}>
          Add Menu Item
        </Text>
      </TouchableOpacity>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View>
              <Text>
                {item.name}
              </Text>

              <Text>
                {item.course}
              </Text>
            </View>

            <TouchableOpacity
              style={styles.delete}
              onPress={() =>
                deleteItem(item.id)
              }
            >
              <Text
                style={{
                  color:"white"
                }}
              >
                Delete
              </Text>
            </TouchableOpacity>
          </View>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20},
  input:{
    borderWidth:1,
    padding:10,
    marginBottom:10
  },
  row:{
    flexDirection:"row",
    marginBottom:10
  },
  courseBtn:{
    borderWidth:1,
    padding:10,
    marginRight:5
  },
  selected:{
    backgroundColor:"#ddd"
  },
  button:{
    backgroundColor:"black",
    padding:10
  },
  btnText:{
    color:"white",
    textAlign:"center"
  },
  card:{
    flexDirection:"row",
    justifyContent:"space-between",
    backgroundColor:"#f2f2f2",
    padding:10,
    marginTop:10
  },
  delete:{
    backgroundColor:"red",
    padding:10
  }
});