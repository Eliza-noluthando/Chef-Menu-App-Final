import React from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet
} from "react-native";

export default function HomeScreen({
  navigation,
  menu
}) {

  const calculateAverage = (course) => {
    const items = menu.filter(
      (item) => item.course === course
    );

    if (items.length === 0) return "0.00";

    const total = items.reduce(
      (sum, item) => sum + item.price,
      0
    );

    return (total / items.length).toFixed(2);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Chef Menu App
      </Text>

      <Text>
        Total Menu Items: {menu.length}
      </Text>

      <Text>
        Starter Average: R
        {calculateAverage("Starter")}
      </Text>

      <Text>
        Main Average: R
        {calculateAverage("Main")}
      </Text>

      <Text>
        Dessert Average: R
        {calculateAverage("Dessert")}
      </Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() =>
          navigation.navigate("Add Menu")
        }
      >
        <Text style={styles.buttonText}>
          Add Menu Items
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() =>
          navigation.navigate("Filter")
        }
      >
        <Text style={styles.buttonText}>
          Filter Menu
        </Text>
      </TouchableOpacity>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.food}>
              {item.name}
            </Text>

            <Text>
              {item.description}
            </Text>

            <Text>
              {item.course} | R{item.price}
            </Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:20
  },
  title:{
    fontSize:24,
    fontWeight:"bold",
    marginBottom:10
  },
  button:{
    backgroundColor:"black",
    padding:10,
    marginVertical:5,
    borderRadius:8
  },
  buttonText:{
    color:"white",
    textAlign:"center"
  },
  card:{
    backgroundColor:"#f2f2f2",
    padding:10,
    marginVertical:5,
    borderRadius:8
  },
  food:{
    fontWeight:"bold",
    fontSize:18
  }
});