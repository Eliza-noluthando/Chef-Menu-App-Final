import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet
} from "react-native";

export default function FilterScreen({
  menu
}) {

  const [filter,
    setFilter] =
    useState("All");

  const filteredMenu =
    filter === "All"
      ? menu
      : menu.filter(
          item =>
            item.course === filter
        );

  return (
    <View style={styles.container}>

      <View style={styles.row}>

        <TouchableOpacity
          style={styles.btn}
          onPress={() =>
            setFilter("All")
          }
        >
          <Text>All</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.btn}
          onPress={() =>
            setFilter("Starter")
          }
        >
          <Text>Starter</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.btn}
          onPress={() =>
            setFilter("Main")
          }
        >
          <Text>Main</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.btn}
          onPress={() =>
            setFilter("Dessert")
          }
        >
          <Text>Dessert</Text>
        </TouchableOpacity>

      </View>

      <FlatList
        data={filteredMenu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text>
              {item.name}
            </Text>

            <Text>
              {item.course}
            </Text>

            <Text>
              R{item.price}
            </Text>
          </View>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:20
  },
  row:{
    flexDirection:"row",
    flexWrap:"wrap"
  },
  btn:{
    borderWidth:1,
    padding:10,
    margin:5
  },
  card:{
    backgroundColor:"#f2f2f2",
    padding:10,
    marginTop:10
  }
});